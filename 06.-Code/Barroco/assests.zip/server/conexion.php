<?php
$host = 'sql211.infinityfree.com';
$user = 'if0_39041729';
$pass = 'TlgPBQ2DNPSnlA'; 
$db   = 'if0_39041729_barroco'; 

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}
?>
